import torch, torch.nn as nn
import torch.nn.functional as F
from .backbone.backbone import ConvNeXtBackbone
from .prompt.prompt import ExemplarEncoder
from .heads.heads import FineFuser, Condenser, DensityDecoder
from .losses.losses import (gaussian_density, adaptive_gaussian_density,
                            bayesian_density_loss)

class Counter(nn.Module):
    """Frozen backbone → fuser → exemplar cross-attention → density map.
    Losses: density MSE + count smooth-L1 only."""
    def __init__(self, cfg, cached=False):
        super().__init__()
        self.cfg = cfg; self.S = cfg.image_size; self.cached = cached
        ch_mid, ch_coarse = cfg.backbone_dims
        D = cfg.d_fine
        self.fuser = FineFuser(ch_coarse, ch_mid, d_fine=D)
        # exemplar encoder needed when not cached OR when queue augments prompts
        need_exemplar = (not cached) or cfg.use_queue
        if not cached:
            self.backbone = ConvNeXtBackbone(cfg)
            ch_mid, ch_coarse = self.backbone.out_channels
            self.exemplar = ExemplarEncoder(ch_coarse, cfg.embed_dim,
                                            cfg.exemplar_layers, roi_size=cfg.roi_size)
        elif need_exemplar:
            # semi-cached: h2/h3 from cache, e recomputed online (queue needs fresh embs)
            self.backbone = None
            self.exemplar = ExemplarEncoder(ch_coarse, cfg.embed_dim,
                                            cfg.exemplar_layers, roi_size=cfg.roi_size)
        else:
            self.backbone = None
            self.exemplar = None
        self.cond = Condenser(d_in=D, d_sim=cfg.embed_dim, d_out=cfg.cond_dim)
        self.density = DensityDecoder(in_ch=D + cfg.cond_dim, hidden=2*D)

    def train(self, mode=True):
        super().train(mode)
        if self.backbone is not None:
            self.backbone.eval()
        return self

    def forward(self, x, bboxes, points=None, h2=None, h3=None, e=None):
        if self.cached:
            assert h2 is not None and h3 is not None
            # when queue is on, e is recomputed online; otherwise must be provided
            if self.exemplar is not None:
                e = self.exemplar(h3, bboxes, self.S)
            else:
                assert e is not None
        else:
            h2, h3 = self.backbone.forward_feature_map(x)
            e = self.exemplar(h3, bboxes, self.S)
        B, _, Hh, _ = h3.shape
        Hf = Wf = Hh * 4
        fine = self.fuser(h2, h3)                                   # [B,D,Hf,Wf]
        fmap = fine.permute(0, 2, 3, 1).flatten(1, 2)              # [B,M,D]
        cond = self.cond(fmap, e)                                   # [B,M,cond_dim]
        dens = self.density(torch.cat([fine, cond.transpose(1, 2).reshape(B, -1, Hf, Wf)], 1))
        counts = dens.sum((1, 2, 3))
        if points is None:
            return {"pred_counts": counts, "density": dens}
        c = self.cfg
        kw = dict(k=c.gauss_knn, smin=c.sigma_min, smax=c.sigma_max, beta=c.sigma_beta)
        if c.density_loss == "mse":
            gt_d = gaussian_density(points, B, Hf, Wf, self.S, sigma=c.gauss_sigma)
            loss_den = F.mse_loss(dens, gt_d)
        elif c.density_loss == "ada_mse":
            gt_d = adaptive_gaussian_density(points, B, Hf, Wf, self.S, **kw)
            loss_den = F.mse_loss(dens, gt_d)
        elif c.density_loss == "bl":
            loss_den = bayesian_density_loss(dens, points, Hf, Wf, self.S, **kw)
        else:
            raise ValueError(f"unknown density_loss {c.density_loss}")
        N = torch.tensor([len(q) for q in points], device=dens.device, dtype=torch.float32)
        loss_cnt = F.smooth_l1_loss((counts+1).log(), (N+1).log())
        loss = self.cfg.density_weight*loss_den + self.cfg.cnt_weight*loss_cnt
        return {"loss": loss, "pred_counts": counts.detach(), "density": dens,
                "loss_den": loss_den.detach(), "loss_cnt": loss_cnt.detach()}
