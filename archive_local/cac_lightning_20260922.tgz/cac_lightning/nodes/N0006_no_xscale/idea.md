# N0006_no_xscale — XScale 消融
## Title
去掉 XScale 多尺度 exemplar
## Motivation
XScale +0.95，验证
## Architecture Spec
use_xscale=false
## Hypotheses
IF XScale removed THEN MAE +0.9
