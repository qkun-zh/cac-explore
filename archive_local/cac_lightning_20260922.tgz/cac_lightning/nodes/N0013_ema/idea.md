# N0013_ema — Exponential Moving Average of weights
## Title
EMA (decay 0.999) of trainable weights, evaluated via EMA shadow
## Motivation
head 轴已闭合 (全部局部最优)。EMA 是架构无关的训练侧机制,通常无任何架构改动即给 0.5-1.5 MAE
提升 (自由午餐)。在计数/密度回归上常稳有收益。
## Architecture Spec
无架构改动;run_node 加 EMACallback (decay 0.999),val 时 swap EMA 权重重评估,BestCheckpoint 存 EMA。
## Hypotheses
IF EMA (0.999) IN FSC147 counting THEN MAE -0.7 vs baseline, BECAUSE 权重平均平滑 SGD 噪声、缓解
末轮震荡, DISPROVED IF 10ep gap > -0.2
## Delta
use_ema=true (config only, 复用 shared counter)
