# N0007_deeper_decoder — 更深密度解码器
## Title
Deeper DensityDecoder (3 conv) 提升密度细节
## Motivation
基线 Decoder 仅 2 层 (3x3 -> dilated 3x3)，对高密度区域的细节可能不足。加一层 3x3 可在不增参过多的前提下提升拟合。
## Architecture Spec
DensityDecoder: in_ch -> hidden -> hidden//2 -> hidden//2 -> 1 (3 conv, 2 GN+GELU, 最后 1x1)
## Hypotheses
IF deeper decoder THEN MAE -0.5
## Delta vs Parent
仅改 decoder 深度
