# N0009_no_gca — GCA 移除 (champion candidate)
## Title
Remove GCA auxiliary count head (champion)
## Motivation
N0005 no_gca 10ep best 25.16 vs baseline 26.02 (-0.86 better). GCA's global count bias harms density sum on FSC147. Promote to full 32ep.
## Architecture Spec
use_gca=false, use_xscale=true (keep XScale, which is load-bearing +2.67 when removed)
## Hypotheses
IF GCA removed AND XScale kept THEN MAE < baseline 22.19 (better)
## Delta
use_gca=false
