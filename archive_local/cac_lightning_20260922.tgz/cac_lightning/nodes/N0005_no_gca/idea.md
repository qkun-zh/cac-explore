# N0005_no_gca — GCA 消融
## Title
去掉 GCA 的计数辅助头
## Motivation
GCA 历史贡献 +1.6，验证其在新 Lightning 引擎下是否仍成立
## Architecture Spec
use_gca=false，其余同 baseline
## Hypotheses
IF GCA removed THEN MAE +1.5
## Delta
关 GCA
