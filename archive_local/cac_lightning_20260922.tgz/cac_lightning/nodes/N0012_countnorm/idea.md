# N0012_countnorm — Decoder 内建 count-consistency 归一化
## Title
Spatial count-consistency self-normalization in DensityDecoder
## Motivation
head_census 结论: 单点超参全在局部最优,真空间在跨组件联合。GCA 是独立 aux,仅给 density 一个
微小常数 bias (0.02/n),太弱。把全局计数直接作用到 density 的空间尺度上——预测 n,然后让
density 在 sum 与 n 之间做可学习 blend 归一化,使空间输出自身符合计数一致。
## Architecture Spec
CountingHead: 计算 n_aux (复用 GCA head, 但改读 density 前特征)。Decoder 输出 raw density d_raw;
计算 dense 归一化 d_norm = d_raw * n_aux / max(sum(d_raw),eps);用可学习标量 w (sigmoid) 混合:
d = w*d_raw + (1-w)*d_norm。w 从 fine+cond 的 GAP 预测。整条可微。
## Hypotheses
IF spatial count-consistency norm IN decoder THEN MAE -0.6 vs baseline, BECAUSE 强于 GCA 的常数
bias,直接约束 density 空间积分与全局计数一致, DISPROVED IF 10ep gap > -0.2
## Delta
head: GCA 常数 bias -> decoder 内 count-consistency blend 归一化 (use_xscale 保持)
