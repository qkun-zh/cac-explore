# N0001_hs2_only — hs2 单层对照

## Title
仅使用 hs2 (192ch 48×48) 的计数能力

## Motivation & Intuition
基线 hs(2,3) 融合了 48×48 的中层纹理与 24×24 的高层语义。单独 hs2 保留了最高分辨率的中间特征，但缺乏 hs3 的 384ch 高层语义，预期在 exemplar 匹配上欠缺“物体性”抽象，尤其对大尺度变化敏感。

## Architecture Spec
* Backbone: `hs_map=(2,2)`，双路输入均为 hs2 (192ch)，`backbone_dims=[192,192]`，其余与基线一致（Fuser/Exemplar/Condenser/Decoder）
* 冻结 backbone，仅训练 head（3.5M）
* 输入 384，bs16，amp

## Proposed Hypotheses
* H_BB1: hs2-only MAE +3~5 vs baseline

## Delta vs Parent
Parent = baseline hs(2,3) frozen。Delta = 去掉 hs3，仅用 hs2 duplicated

## Novelty Statement
非创新，仅为机制验证的消融对照

## Falsification
3轮对照中 MAE gap <1.0 则 H_BB1 证伪
