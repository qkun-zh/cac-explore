# N0008_light_decoder — 轻量密度解码器
## Title
Lighter Decoder (hidden 192) 减少参数量/正则
## Motivation
N0007 更深的 decoder 反而 10轮 +2.5 差，说明 decoder 过拟合/容量过剩。轻量 decoder (hidden 192，单2层) 应更稳。
## Architecture Spec
DensityDecoder in_ch=768 -> 192 (dilated 3x3) -> 96 -> 1；hidden 从 256 降 192
## Hypotheses
IF light decoder THEN MAE -1
## Delta
hidden 256->192
