# N0016_exemplar_route — 可学习 exemplar 深度路由 (Exemplar Depth-Routing)

## Title
Router learns per-exemplar depth mix (h3 detail vs h4 semantics) — replace fixed additive fusion

## Motivation & Intuition
N0015 证明 h3+h4 加性融合（-0.51）优于任一单源，但它是**固定 50/50**——对所有 exemplar
用相同权重。DCA-MoE (arXiv:2608.15213, 2026) 指出这种固定融合的问题：
"applies the same feature-depth preference across sparse and congested regions"，并用
SALF（空间/内容自适应跨层融合）把固定求和换成**逐位置可学习权重**，取得显著增益。

在 CAC 中，不同类型/尺度的目标 exemplar 需要不同深度的特征——有的主要靠空间细节区分，
有的靠语义类别区分。固定 50/50 无法为每类选最优深度。本节点给 N0015 的双分支加一个
**轻量 router**：对每个 exemplar 预测 [w_mid, w_final] softmax 权重，soft 加权融合。

## Architecture Spec
- Backbone 输出 h2,h3（density）+ h4（exemplar 语义）
- 双分支 exemplar：branch_mid (h3, proj 384→d)、branch_final (h4, proj 768→d)
- **Router**：对每个 exemplar 用 GAP 后的原始 ROI 特征 → Linear → 2-logits
  → temperature-softmax → [w_mid, w_final]
- 融合：e = w_mid * e_mid + w_final * e_final（soft weighted）
- 温度初始低（=居中权重 ~0.5/0.5），从 N0015 起点学，让 density loss 决定深度偏好
- 共享 transformer + attn pool（同 N0015，控制参数）

## Delta vs Parent (N0015)
- N0015: e = e_mid + e_final（固定 1.0/1.0）
- N0016: e = w_mid*e_mid + w_final*e_final（可学习软路由）

## Proposed Hypotheses
IF per-exemplar learnable depth routing (h3 vs h4 softmixture) IN FSC147 counting,
THEN MAE 低于 N0015 (21.68)，
BECAUSE 不同类型/尺度 exemplar 对空间细节 vs 类别语义的需求不同，固定 50/50 欠配，
可学习路由按 exemplar 内容自适应选深度（DCA-MoE SALF 思想）。
DISPROVED IF 32ep best_mae >= 21.68。

## Novelty Statement
把 DCA-MoE 的空间自适应跨层融合（SALF）思想首次应用到 CAC 的 **exemplar** 读取融合：
由可学习 router 决定中间层/最终层深度偏好，而非固定相加。与 N0015 固定融合严格对照。
