# N0014_exemplar_deep — 中间层算密度，最终层抠 Exemplar

## Title
Decouple readout depth by role: density from intermediate hs(2,3), exemplar from final layer hs[4]

## Motivation & Intuition
三篇近期工作共同指出：预训练视觉模型的中间层是"计数量子语义"的甜点（不丢空间细节的
物体性表征），而最终层被分类头拉偏、语义高度类别特化。但在 CAC 中，density 与
exemplar 是两种不同的读取需求：

- **Density**：需要空间细节去定位每个物体 → 中间层 hs(2,3)（保持 baseline load-bearing）
- **Exemplar**：需要回答"这个目标类别长什么样" → 最终层 hs[4]（768ch 分类特化语义最rich）

当前 baseline 把 exemplar 和 density 都从中间层读（ExemplarEncoder 用 h3）。
本节点假设：exemplar 的类别外观语义其实在最终层更充分，把 exemplar 读取切换到
hs[4] 能提升跨类泛化的匹配质量，而 density 不受影响（仍在中间层最优处）。

对应文献：
- Pre-trained Models Can Count (CVPR'26): 中间层特征含单调计数结构 → density 留在中间层
- Causality≠Decodability (Counting ViTs): 中间层 token 因果活跃（被功能使用）、
  最终层 token 可解码但功能惰性 → 解读成"最终层含丰富语义但需显式读出"，
  而我们正把 exemplar 读取显式放在最终层
- MLLMs See Better Shallower: 计数/定位偏好浅中层 → density 不该用深层

## Architecture Spec
精简 head，去掉 GCA/DDCA，仅保留核心：FineFuser + ExemplarEncoder + Condenser +
DensityDecoder。

- Backbone 同时输出 hs_map=(2,3) 给 density + hs[4] (768ch, 12×12) 给 exemplar
- ExemplarEncoder.in_dim = 768（final 通道），ROI-Align 从 hs4 抠，proj 768→256
- Condenser 跨注意力让 96×96 空间位置 attend 到 exemplar tokens
- DensityDecoder 融合 fine + cond → density map
- 砍掉 GCA（旧信任度 marginal）、DDCA（已被证有害）

## Delta vs Parent
- exemplar 读取源从 h3 → hs[4] 最终层（核心改动，理论支撑）
- 顺带精简删去 GCA/DDCA 死重（不让旧组件干扰新信号）

## Proposed Hypotheses
IF exemplar 从最终层 hs[4] 抠（而非中间层 h3） IN FSC147 CAC,
THEN MAE 下降 (vs baseline 22.19),
BECAUSE 最终层分类特化语义能更精确刻画 exemplar 类别外观，提升跨类匹配质量，
而 density 仍在中间层不受损。
DISPROVED IF 32ep MAE >= baseline（+0 或更差）在 3 轮独立 seed 下 >0.5 差距内不确认。

## Novelty Statement
现有 2×2 消融锁定的是"整体 readout 层 × 冻结状态"，从未把 density 与 exemplar 的
读取深度**解耦**。本节点是首次将 exemplar 读取显式放到最终层、density 留在中间层，
由机制可解释性（因果≠可解码）驱动的结构级创新而非超参微调。
