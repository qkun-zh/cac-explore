# N0002_hs3_only — hs3 单层对照
## Title
仅使用 hs3 (384ch 24×24) 的计数能力
## Motivation
hs3 有高层语义但分辨率仅 24，需 4× 上采样到 96，细粒度定位可能丢失。
## Architecture Spec
hs_map=(3,3), dims [384,384], 其余同基线
## Proposed Hypotheses
H_BB2
## Delta vs Parent
去掉 hs2，仅用 hs3 duplicated
## Falsification
3轮 gap <1.0 证伪
