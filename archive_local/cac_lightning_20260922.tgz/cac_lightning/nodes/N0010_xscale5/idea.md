# N0010_xscale5 — XScale coarse scale 3->5
## Title
Enlarge XScale coarse pool (xs=5) for better scale invariance
## Motivation
XScale is load-bearing (removing +2.67 @10ep). Its coarse global summary currently pools at 3x3. Enlarging to 5x5 captures more context per exemplar, improving scale-invariance.
## Architecture Spec
use_xscale=true, xscale_size=5 (vs baseline 3)
## Hypotheses
IF xscale_size 5 IN FSC147 counting THEN MAE -0.5 vs baseline
## Delta
xscale_size=3->5
