# N0011_xscale_ctx — XScale 用 coarse 做 cross-attention 而非 add
## Title
Coarse-global → cross-attention fusion (not additive) in ExemplarEncoder
## Motivation
XScale 是 head 里唯一确认 load-bearing 的组件 (移除 +2.67 @10ep)。当前 coarse 全局摘要只是
GAP+Linear 后与 fine 特征简单相加 (add),coarse 信息无法"引导"fine 的池化。改用 coarse 做 query、
fine 做 key/value 的 cross-attention,让 coarse 尺度语境语义化地调制 exemplar 摘要。
## Architecture Spec
ExemplarEncoder: fine ROI 先过 self-attn;coarse 全局摘要 (xs=3 GAP,1 tok/exemplar) 与 fine
tokens 过 1 层 cross-attn (coarse q x fine kv), 输出 coarse-cond token, 与出去池化后的 fine 摘要
cat 后经 1 层 Linear 融合。
## Hypotheses
IF coarse→cross-attn fusion IN FSC147 THEN MAE -0.7 vs baseline, BECAUSE 尺度语境能引导 fine 池化
而非仅加性偏置, DISPROVED IF 10ep gap > -0.2
## Delta
xscale 融合方式: add -> cross-attn (keeps xs=3)
