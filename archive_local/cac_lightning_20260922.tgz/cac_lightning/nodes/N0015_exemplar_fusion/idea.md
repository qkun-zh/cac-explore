# N0015_exemplar_fusion — 中间层 + 最终层 双分支 Exemplar 融合

## Title
Fuse intermediate (h3) and final (h4) exemplar readouts: detail + semantics

## Motivation & Intuition
N0014 证明 exemplar 单独从 final 层读（12×12）是 viable 但略逊（22.67 vs 22.19, +0.48）。
原因：final 层有 rich 类别语义，但 12×12 空间分辨率丢失了 exemplar 所需的空间细节。

于是自然的问题是：能否**兼得**？ baseline 用中间层 h3（空间细节好、语义够用），N0014 用
final h4（语义 rich、细节差）。两者是互补的两个维度 —— 这正是论文3
"Multimodal LMs See Better When They Look Shallower" 的核心主张：**浅-中-深特征融合优于
单层选取**。论文3 用简单线性投影融合浅/中/深三层特征，取得一致增益。

本节点把同一思想移植到 exemplar 读取：同时从 h3 和 h4 抠 ROI，各投影到相同 embed_dim，
**加性融合**成一个 exemplar token 喂给 Condenser。中间层提供空间细节，final 层提供类别
语义，single exemplar embedding 同时携带两者。

## Architecture Spec
- Backbone 输出 h2, h3（density）+ h4（exemplar 语义分支）
- ExemplarEncoder 双通道：
  - ch_A: ROI-Align from h3 (384ch, 24×24), proj 384→256
  - ch_B: ROI-Align from h4 (768ch, 12×12), proj 768→256
  - 各自过共享/独立 Transformer + attn pool → 两个 exemplar 向量 → 相加
- 其余同 N0014（无 GCA/DDCA，精简 head）

## Delta vs Parent (baseline)
- 相对 baseline：exemplar 增加 final 层 h4 语义分支（加性融合），density 不变
- 相对 N0014：不放弃中间层 exemplar，改为双分支融合

## Proposed Hypotheses
IF 融合中间层 h3 + final h4 的 exemplar readout (additive) IN FSC147 counting,
THEN MAE 低于 baseline 22.19,
BECAUSE 中间层提供空间细节、final 层提供类别语义，互补融合比任一单源更能精确示例类别外观，
且不损失 density（仍在中间层）。
DISPROVED IF 32ep best_mae >= baseline（+0 或更差）。

## Novelty Statement
N0014/2×2 均用**单一**读源；本节点将论文3 的浅-中-深融合思想首次应用于 CAC 的 exemplar
读取（而非 density），在 32M 预算内用加性融合替代单层二选一。
