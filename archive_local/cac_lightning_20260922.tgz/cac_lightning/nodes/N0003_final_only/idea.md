# N0003_final_only — final 层对照
## Title
仅使用 hs4 final (768ch 12×12)
## Motivation
Final 层分类特化且过粗 12×12，需 8× 上采样，预期最差 +7
## Architecture Spec
hs_map=(4,4), dims [768,768]
## Proposed Hypotheses
H_BB3
## Delta vs Parent
用 final 代替 intermediate
## Falsification
gap <3.0 证伪
