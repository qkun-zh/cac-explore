# N0004_unfrozen — 解冻对照
## Title
hs(2,3) 解冻微调的危害
## Motivation
解冻 27.8M backbone 在 6k 图上过拟合，破坏 DINO 通用计数语义
## Architecture Spec
hs_map=(2,3) dims [192,384] 但 backbone requires_grad True
## Proposed Hypotheses
H_BB4
## Delta vs Parent
解冻
## Falsification
gap <2.0 证伪
