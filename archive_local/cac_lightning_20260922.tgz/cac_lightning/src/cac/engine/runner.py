"""Runner — wires config -> DataModule + CountingLit -> Trainer -> fit.

Deep-ish module: the call sites only need `run(cfg, run_dir, ...)`. Behind it
Lightning Trainer handles AMP, gradient clipping, deterministic seeding, and
scheduling; BestCheckpoint writes best.pth; the returned result dict is the
canonical result.json shape for this repo.

Interface:
  run(cfg, run_dir, name="cac") -> dict  # runs full fit, returns result dict
"""
from __future__ import annotations

import json
import math
import os
import time
from typing import Any

import torch
from lightning.pytorch import Trainer
from lightning.pytorch.callbacks import ModelCheckpoint

from cac.calls import BestCheckpoint, EMACallback
from cac.data import FSC147DataModule
from cac.hub import setup_hf_env
from cac.models import make_model
from cac.models.pl_module import CountingLit


def _load_node_model(model_file: str):
    """Load a node's local model.py, returning its build_model(cfg)->nn.Module."""
    import importlib.util
    spec = importlib.util.spec_from_file_location("node_model", model_file)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    if not hasattr(mod, "build_model"):
        raise RuntimeError(f"node model {model_file} must expose build_model(cfg)")
    return mod.build_model


def _build(cfg: dict[str, Any], model_file: str | None):
    if model_file is not None:
        return _load_node_model(model_file)(cfg)
    return make_model(cfg)


def _seed(seed: int | None) -> None:
    import random
    import numpy as np
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


def run(cfg: dict[str, Any], run_dir: str, name: str = "cac",
        smoke: bool = False, max_epochs: int | None = None,
        model_file: str | None = None) -> dict[str, Any]:
    """Train a counting model with Lightning and return a result dict.

    Writes run_dir/result.json (status/metrics/timing/diagnostics) as it goes
    (or at least at the end), plus run_dir/best.pth via BestCheckpoint.
    """
    os.makedirs(run_dir, exist_ok=True)
    setup_hf_env()
    cfg = dict(cfg)
    cfg.setdefault("_config_source", "toml")
    run_seed = cfg.get("seed")
    if run_seed is not None:
        _seed(int(run_seed))

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    # allow forcing accelerator (e.g. CPU smoke while the GPU is otherwise busy)
    accel_override = os.environ.get("CAC_ACCELERATOR")
    if accel_override is not None:
        device = torch.device(accel_override)
    use_amp = bool(cfg.get("amp", True)) and device.type == "cuda"
    smoke_s = smoke or bool(cfg.get("smoke", False))
    t_start = time.time()

    model = _build(cfg, model_file).to(device)
    total_p = sum(q.numel() for q in model.parameters()) / 1e6
    max_p = float(cfg.get("max_params_M", 32))
    if total_p >= max_p:
        raise RuntimeError(f"params {total_p:.2f}M over budget {max_p}M")

    lit = CountingLit(cfg, model=model)
    dm = FSC147DataModule(
        cfg,
        data_root=str(cfg.get("data_root", "/data/dataset/FSC147")),
        img_size=int(cfg.get("input_size", 384)),
        batch_size=int(cfg.get("batch_size", 8)),
        num_workers=int(cfg.get("num_workers", 4)),
        augment=bool(cfg.get("augment", False)),
        seed=int(run_seed) if run_seed is not None else None,
        smoke=smoke_s,
    )

    epochs = max_epochs or int(cfg.get("epochs", 10))
    best_ckpt = BestCheckpoint(run_dir)
    callbacks: list[Any] = [best_ckpt]
    if bool(cfg.get("use_ema", False)):
        callbacks.append(EMACallback(decay=float(cfg.get("ema_decay", 0.999))))
    trainer_kw: dict[str, Any] = dict(
        accelerator="gpu" if device.type == "cuda" else "cpu",
        devices=1,
        max_epochs=epochs,
        default_root_dir=run_dir,
        log_every_n_steps=1,
        enable_progress_bar=False,
        enable_checkpointing=False,   # custom BestCheckpoint writes best.pth
        callbacks=callbacks,
        deterministic=False,  # was (run_seed is not None) -> Lightning's full use_deterministic_algorithms is 2.4x slower (133s vs 55s/epoch); manual _seed() already sets cudnn.deterministic for reproducibility
    )
    if device.type == "cuda" and cfg.get("use_amp", True):
        # fp16 + GradScaler. CPU: leave scalar-precision.
        trainer_kw["precision"] = "16-mixed"
    if smoke_s:
        trainer_kw["limit_train_batches"] = 3
        trainer_kw["limit_val_batches"] = 2
        trainer_kw["min_epochs"] = 1
        trainer_kw["max_epochs"] = min(epochs, 2)

    trainer = Trainer(**trainer_kw)
    trainer.fit(lit, datamodule=dm)
    epochs_done = trainer.current_epoch + 1
    mae = float(best_ckpt.best) if math.isfinite(best_ckpt.best) else float("nan")

    # final metrics
    val_mae = float(trainer.callback_metrics.get("val/mae", float("nan")))
    val_rmse = float(trainer.callback_metrics.get("val/rmse", float("nan")))
    final_mae = val_mae if math.isfinite(val_mae) else float("nan")
    final_rmse = val_rmse if math.isfinite(val_rmse) else float("nan")

    result = {
        "node": name,
        "status": "success",
        "metrics": {"mae": final_mae, "rmse": final_rmse, "best_mae": mae},
        "timing": {"train_seconds": round(time.time() - t_start, 1), "epochs_done": epochs_done},
        "diagnostics": {"params_M": round(total_p, 2), "smoke": smoke_s,
                        "seed": run_seed, "config_source": cfg.get("_config_source")},
        "run_dir": run_dir,
        "ts": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
    }
    json.dump(result, open(os.path.join(run_dir, "result.json"), "w"), indent=2, ensure_ascii=False)
    return result