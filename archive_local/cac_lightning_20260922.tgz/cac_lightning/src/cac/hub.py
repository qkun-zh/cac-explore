"""HF hub helpers: env setup + optional token.

HF_HOME/HF_ENDPOINT are set in the runner for the server (persistent cache at
/data/asset/hf, mirror at hf-mirror.com). `hf_token` reads a token file if
present (needed only for gated repos), else returns None.
"""
from __future__ import annotations

import os
from pathlib import Path


def setup_hf_env() -> None:
    os.environ.setdefault("HF_HOME", "/data/asset/hf")
    os.environ.setdefault("HF_ENDPOINT", "https://hf-mirror.com")
    os.environ.setdefault("HF_HUB_OFFLINE", "0")


def hf_token() -> str | None:
    for p in ("/tmp/hf_token.txt", str(Path.home() / ".cache/huggingface/token")):
        if os.path.exists(p):
            return open(p).read().strip()
    return None
