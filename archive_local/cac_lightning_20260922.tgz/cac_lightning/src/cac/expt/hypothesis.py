"""Hypothesis memory bank.

Encapsulates the append-only ledger, the canonical format gate, the confidence
update rule, and index materialization. Callers interact with a high-level API:

  mem = Memory(repo)
  mem.create(hyp_id, text, source=None) -> None      # append a create event
  mem.evidence(hyp_id, evidence_type, strength, source_node) -> None
  mem.validate(text) -> (errors, warnings)           # format gate
  mem.build_index() -> dict                          # materialize ledger -> index
  mem.summary() -> str                               # concise human report

Ledger is append-only (events are never edited; corrections are new events).
"""
from __future__ import annotations

import json
import os
import re
import time
from typing import Any

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

# --- canonical hypothesis format -------------------------------------------------
MARKERS = ["IF", "IN", "THEN", "BECAUSE", "DISPROVED"]
_MARKER_RE = [(m, re.compile(rf"\b{m}\b")) for m in MARKERS]
_FALSIFIER_RE = re.compile(r"DISPROVED\s+IF\s*(.+)$", re.DOTALL)
_MEASURE = re.compile(r"(<=|>=|==|<|>|\d)", re.IGNORECASE)
_MECHANISM_MIN = 20


def validate(text: str) -> tuple[list[str], list[str]]:
    """7-dim gate (automated subset): markers/order, non-empty segments,
    measurable falsifier, scope/mechanism length. Returns (errors, warnings)."""
    errors, warnings = [], []
    raw = text.strip()
    if not raw:
        return ["empty text"], []

    pos, last = [], -1
    for m, rx in _MARKER_RE:
        mt = rx.search(raw)
        if not mt:
            errors.append(f"missing marker {m!r}")
            pos.append(None)
        else:
            pos.append(mt.start())
            if mt.start() < last:
                errors.append(f"marker {m!r} out of order")
            last = max(last, mt.start())

    complete = len(pos) == 5 and all(p is not None for p in pos)

    def seg(a: int, b: int) -> str:
        return raw[pos[a] + len(MARKERS[a]):pos[b]].strip(" ,.:;")

    if complete:
        for idx, name, nxt in ((0, "choice", 1), (1, "scope", 2), (2, "effect", 3), (3, "mechanism", 4)):
            s = seg(idx, nxt)
            if not s:
                errors.append(f"empty [{name}]")
            elif name == "mechanism" and len(s) < _MECHANISM_MIN:
                warnings.append(f"mechanism very short ({len(s)} chars)")

    fm = _FALSIFIER_RE.search(raw)
    falsifier = fm.group(1).strip() if fm else ""
    if "DISPROVED" in raw:
        if not falsifier:
            errors.append("empty falsification criterion")
        elif not _MEASURE.search(falsifier):
            errors.append("falsifier not measurable: needs a number/comparison (e.g. MAE>=X)")
        if re.search(r"\bOR\b", falsifier) and not re.search(r"\bAND\b", falsifier):
            warnings.append("compound OR-falsifier: ensure every disjunct alone kills the hyp")

    if len(raw) > 1200:
        warnings.append(f"hypothesis very long ({len(raw)} chars)")
    if re.search(r"\bmaybe\b|\bperhaps\b|\bmight\b", raw, re.IGNORECASE):
        warnings.append("hedging language in a falsifiable claim")
    return errors, warnings


def apply_evidence(conf: float, evidence_type: str, strength: float, eta: float) -> float:
    """η-rule: supports c<-c+η·w·(1-c); contradicts c<-c-η·w·c."""
    if evidence_type == "supports":
        return conf + eta * strength * (1 - conf)
    return conf - eta * strength * conf  # contradicts / neutral treated as contradict


class Memory:
    def __init__(self, repo: str = ROOT, eta: float = 0.20):
        self.repo = repo
        self.eta = eta
        self.ledger = os.path.join(repo, "memory", "hypotheses.jsonl")
        self.index_path = os.path.join(repo, "memory", "index.json")

    # ---- ledger (append-only) ---------------------------------------------------
    def _append(self, ev: dict[str, Any]) -> None:
        ev = {"ts": time.strftime("%Y-%m-%dT%H:%M:%S%z"), **ev}
        with open(self.ledger, "a") as f:
            f.write(json.dumps(ev, ensure_ascii=False) + "\n")

    def create(self, hyp_id: str, text: str, source: str | None = None) -> None:
        errs, _ = validate(text)
        if errs:
            raise ValueError(f"hypothesis fails format gate: {errs}")
        self._append({"type": "create", "hyp_id": hyp_id, "text": text,
                      "evidence_type": "create", "source_node": source})

    def evidence(self, hyp_id: str, evidence_type: str, strength: float,
                 source_node: str, note: str | None = None) -> None:
        self._append({"type": "evidence", "hyp_id": hyp_id, "evidence_type": evidence_type,
                      "strength": float(strength), "source_node": source_node, "note": note})

    def events(self) -> list[dict[str, Any]]:
        if not os.path.exists(self.ledger):
            return []
        return [json.loads(l) for l in open(self.ledger) if l.strip()]

    # ---- index materialization --------------------------------------------------
    def build_index(self) -> dict[str, Any]:
        """Replay the ledger into a materialized {hyp_id: {text, confidence, status, log}}."""
        hyp: dict[str, Any] = {}
        for ev in self.events():
            hid = ev.get("hyp_id")
            h = hyp.setdefault(hid, {"text": None, "confidence": 0.5, "status": "uncertain",
                                     "n_tested": 0, "log": []})
            if ev["type"] == "create":
                h["text"] = ev.get("text")
            elif ev["type"] == "evidence":
                h["confidence"] = apply_evidence(h["confidence"], ev["evidence_type"],
                                                 float(ev.get("strength", 1.0)), self.eta)
                h["n_tested"] += 1
            h["log"].append({"type": ev["type"], "ts": ev["ts"], **{k: ev[k] for k in
                             ("evidence_type", "strength", "source_node", "note") if k in ev}})
            if h["confidence"] > 0.75:
                h["status"] = "confirmed"
            elif h["confidence"] < 0.25:
                h["status"] = "refuted"
        # drop empty buckets that never received a create
        for hid in list(hyp):
            if not hyp[hid]["text"]:
                del hyp[hid]
        idx = {"_meta": {"eta": self.eta}, "rebuilt": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
               "hypotheses": hyp}
        os.makedirs(os.path.dirname(self.index_path), exist_ok=True)
        json.dump(idx, open(self.index_path, "w"), indent=2, ensure_ascii=False)
        return idx

    def summary(self) -> str:
        hyp = self.build_index()["hypotheses"]
        if not hyp:
            return "(no hypotheses yet)"
        lines = [f"{'id':<14}{'conf':>6}  {'status':<10} text"]
        for hid, h in hyp.items():
            lines.append(f"{hid:<14}{h['confidence']:>6.2f}  {h['status']:<10} {str(h['text'])[:70]}")
        return "\n".join(lines)
