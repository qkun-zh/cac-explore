"""Experiment orchestration (HypoExplore machinery, Lightning-era rewrite).

deep modules:
  Memory         — hypothesis ledger (append-only) + format gate + confidence updates + index
  TrajectoryTree — trajectory tree + dual selection (parent, hypotheses)
  Calibration    — hypothesis prediction calibration monitor

A single `memory/` + `tree/` lives at the repo root, shared by all nodes.
"""
from cac.expt.hypothesis import Memory, validate, apply_evidence  # noqa: F401
from cac.expt.tree import TrajectoryTree  # noqa: F401
from cac.expt.gates import Calibration  # noqa: F401
