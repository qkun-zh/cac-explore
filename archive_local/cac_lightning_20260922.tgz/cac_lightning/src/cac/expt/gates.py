"""Calibration monitor (§4.3): is the memory bank well-calibrated?

Replays the ledger in order, reconstructs confidence c(h) just before each
evidence event, and reports whether each hypothesis prediction was correct
(supports=hit, contradicts=miss) binned by confidence-at-test. Read-only.
"""
from __future__ import annotations

import json
import os
from typing import Any

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

BINS = [(0.25, 0.50), (0.50, 0.75), (0.75, 1.001)]
CLASS_CONFIRMED = 0.75
CLASS_REFUTED = 0.25


def _bin_of(c: float) -> str:
    for lo, hi in BINS:
        if lo <= c < hi:
            return f"[{lo:.2f},{min(hi, 1.0):.2f})"
    return "<0.25"


class Calibration:
    def __init__(self, repo: str = ROOT, eta: float = 0.20):
        self.repo = repo
        self.eta = eta
        self.ledger = os.path.join(repo, "memory", "hypotheses.jsonl")

    def report(self, as_json: bool = False) -> str | dict[str, Any]:
        if not os.path.exists(self.ledger):
            empty = {"bins": {}, "tests": [], "standings": {}, "warnings": []}
            return json.dumps(empty, indent=2) if as_json else "(no ledger)"
        conf: dict[str, float] = {}
        tests: list[dict[str, Any]] = []
        warns: list[str] = []
        for i, line in enumerate(open(self.ledger), 1):
            line = line.strip()
            if not line:
                continue
            try:
                ev = json.loads(line)
            except json.JSONDecodeError as e:
                warns.append(f"L{i}: unparseable — {e}")
                continue
            hid = ev.get("hyp_id")
            typ = ev.get("type")
            if typ == "create":
                conf[hid] = float(ev.get("confidence", 0.5))
            elif typ == "evidence":
                if hid not in conf:
                    warns.append(f"L{i}: evidence for unknown {hid}")
                    continue
                etype = ev.get("evidence_type")
                w = float(ev.get("strength", 1.0))
                c0 = conf[hid]
                if etype == "supports":
                    hit, c1 = True, c0 + self.eta * w * (1 - c0)
                elif etype == "contradicts":
                    hit, c1 = False, c0 - self.eta * w * c0
                else:  # neutral: logged, not scored
                    hit, c1 = None, c0
                tests.append({"hyp": hid, "conf_before": round(c0, 4), "hit": hit,
                              "node": ev.get("source_node", "?"), "strength": w})
                conf[hid] = min(0.99, max(0.01, c1))
            else:
                warns.append(f"L{i}: unknown event type {typ!r}")

        agg = {f"[{lo:.2f},{min(hi, 1.0):.2f})": {"n": 0, "hits": 0} for lo, hi in BINS}
        agg["<0.25"] = {"n": 0, "hits": 0}
        for t in tests:
            if t["hit"] is None:
                continue
            b = _bin_of(t["conf_before"])
            agg[b]["n"] += 1
            agg[b]["hits"] += int(t["hit"])

        if as_json:
            return {"bins": agg, "tests": tests,
                    "standings": {h: round(c, 4) for h, c in sorted(conf.items())},
                    "warnings": warns}

        lines = [f"=== Hypothesis Prediction Calibration (eta={self.eta:.2f}) ===",
                 f"{'conf@test':<14}{'N':>4}{'correct':>9}{'rate':>8}"]
        total_n = total_hits = 0
        for b in agg:
            n, h = agg[b]["n"], agg[b]["hits"]
            total_n += n
            total_hits += h
            lines.append(f"{b:<14}{n:>4}{h:>9}{(f'{h/n:.0%}' if n else '-'):>8}")
        if total_n:
            lines.append(f"{'overall':<14}{total_n:>4}{total_hits:>9}{f'{total_hits/total_n:.0%}':>8}")
        lines.append("\n=== Current Standings ===")
        lines.append(f"{'hyp':<7}{'conf':>7}{'class':<11}{'tests':>6}")
        for h, c in sorted(conf.items()):
            cls = ("confirmed" if c > CLASS_CONFIRMED else "refuted" if c < CLASS_REFUTED else "uncertain")
            n = sum(1 for t in tests if t["hyp"] == h)
            lines.append(f"{h:<7}{c:>7.3f}{cls:<11}{n:>6}")
        if warns:
            lines.append("\nWARNINGS:")
            lines += [" - " + w for w in warns]
        return "\n".join(lines)
