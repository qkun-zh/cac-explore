"""Trajectory tree + dual selection.

Ports the HypoExplore discovery machinery cleanly:
  - Tree: node registry with parent/children/status/metrics/tested hypotheses.
  - select_parent: score = λ_parent·quality + (1−λ_parent)·avail  where
    quality = λ_acc·Acc_norm + (1−λ_acc)·(1 − min(τ,τ_max)/τ_max).
  - select_hypo: Thompson-sampling exploit (top-2) ∪ epistemic explore (top-2),
    deduped, on uncertain & untested-on-chain hypotheses.
"""
from __future__ import annotations

import json
import os
import random
from typing import Any

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))


class TrajectoryTree:
    def __init__(self, repo: str = ROOT):
        self.repo = repo
        self.path = os.path.join(repo, "tree", "tree.json")
        self.data = json.load(open(self.path))

    def save(self) -> None:
        json.dump(self.data, open(self.path, "w"), indent=2, ensure_ascii=False)

    # ---- state access -----------------------------------------------------------
    @property
    def nodes(self) -> dict[str, Any]:
        return self.data["nodes"]

    @property
    def meta(self) -> dict[str, Any]:
        return self.data["_meta"]

    # ---- node lifecycle -----------------------------------------------------------
    def register(self, nid: str, parent: str | None) -> None:
        if nid in self.nodes:
            return
        self.nodes[nid] = {"parent": parent, "children": [], "status": "proposed",
                           "best_metric": None, "train_seconds": None, "tested_hypotheses": []}
        if parent and parent in self.nodes:
            self.nodes[parent]["children"].append(nid)
        self.save()

    def set_status(self, nid: str, status: str) -> None:
        if nid in self.nodes:
            self.nodes[nid]["status"] = status
            self.save()

    def update_metrics(self, nid: str, best_metric: float | None, train_seconds: float | None,
                       tested: list[str] | None = None) -> None:
        n = self.nodes.get(nid)
        if n:
            if best_metric is not None:
                n["best_metric"] = best_metric
            if train_seconds is not None:
                n["train_seconds"] = train_seconds
            if tested:
                n["tested_hypotheses"] = list(dict.fromkeys((n.get("tested_hypotheses") or []) + tested))
            self.save()

    def ancestors(self, nid: str) -> list[dict[str, Any]]:
        chain, cur = [], nid
        while cur:
            n = self.nodes.get(cur)
            if not n:
                break
            chain.append(n)
            cur = n.get("parent")
        return chain

    def next_id(self, prefix: str = "N") -> str:
        existing = [nid for nid in self.nodes if nid.startswith(prefix + "_") or nid.startswith(prefix)]
        nums = []
        for nid in existing:
            m = "".join(ch for ch in nid.split("_")[0] if ch.isdigit())
            if m:
                nums.append(int(m))
        return f"{prefix}{max(nums, default=0) + 1:04d}_"

    # ---- selection ----------------------------------------------------------------
    def select_parent(self, idx: dict[str, Any], verbose: bool = True) -> str | None:
        lam_acc = float(self.meta.get("lambda_acc", 0.85))
        lam_par = float(self.meta.get("lambda_parent", 0.60))
        tau_max = float(self.meta.get("tau_max_min", 30)) * 60
        cand = {k: v for k, v in self.nodes.items() if v.get("status") in ("synthesized", "done")}
        if not cand:
            return None
        accs = [v.get("best_metric", 0.0) or 0.0 for v in cand.values()]
        lo, hi = min(accs), max(accs)
        active = {h for h, m in idx.items() if m.get("status", "uncertain") == "uncertain"}
        best_nid, best_score = None, -1
        rows = []
        for nid, n in cand.items():
            acc_norm = (hi - float(n.get("best_metric", hi) or hi)) / (hi - lo) if hi > lo else 1.0
            tau = min(float(n.get("train_seconds", 0) or 0), tau_max)
            quality = lam_acc * acc_norm + (1 - lam_acc) * (1 - tau / tau_max)
            tested = set()
            for a in self.ancestors(nid):
                tested.update(a.get("tested_hypotheses", []))
            n_tested = len(active & tested)
            avail = 0.0 if not active else 1 - n_tested / len(active)
            score = lam_par * quality + (1 - lam_par) * avail
            rows.append((score, quality, avail, acc_norm, nid))
            if score > best_score:
                best_score, best_nid = score, nid
        if verbose:
            print(f"{'node':<24}{'score':>7}{'qual':>7}{'avail':>7}{'acc_n':>7}")
            for s, q, av, an, nid in sorted(rows, reverse=True):
                print(f"{nid:<24}{s:>7.3f}{q:>7.3f}{av:>7.3f}{an:>7.3f}")
            print(f"\nPARENT -> {best_nid}")
        return best_nid

    def select_hypo(self, parent: str, idx: dict[str, Any], seed: int | None = None,
                    verbose: bool = True) -> list[str]:
        rng = random.Random(seed)
        tested = set()
        for a in self.ancestors(parent):
            tested.update(a.get("tested_hypotheses", []))
        cand = {h: m for h, m in idx.items()
                if m.get("status", "uncertain") == "uncertain" and h not in tested}
        if not cand:
            return []
        scored = []
        for h, m in cand.items():
            sup = sum(e.get("strength", 1.0) for e in m.get("log", []) if e.get("evidence_type") == "supports")
            con = sum(e.get("strength", 1.0) for e in m.get("log", []) if e.get("evidence_type") in ("contradicts", "neutral"))
            theta = rng.betavariate(1 + sup, 1 + con)
            c = float(m.get("confidence", 0.5))
            epistemic = 1 - abs(2 * c - 1)
            scored.append((h, c, sup, con, theta, epistemic, m.get("text", "")[:80]))
        K = int(self.meta.get("k_exploit", 2))
        exploit = sorted(scored, key=lambda r: -r[4])[:K]
        explore = sorted(scored, key=lambda r: -r[5])[:K]
        seen, qt = set(), []
        for r in exploit + explore:
            if r[0] not in seen:
                seen.add(r[0])
                qt.append(r[0])
        if verbose:
            for r in sorted(scored, key=lambda r: -r[4]):
                print(f"{r[0]:<14}{r[1]:>6.2f}{r[2]:>5.1f}{r[3]:>5.1f}  {r[6]}")
            print(f"\nQ_t (parent={parent}) -> {qt}")
        return qt
