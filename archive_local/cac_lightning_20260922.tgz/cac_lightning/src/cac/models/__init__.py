"""Model registry.

`build_model(cfg)` is the stable contract: given a flat dict of settings it
returns an nn.Module whose forward(imgs, bboxes[, bboxes3]) returns
{"density": ..., optional "n_aux"}. The canonical proven architecture lives in
`counter.py`.
"""
from __future__ import annotations

from typing import Any

from cac.models.counter import Counter, build_model  # noqa: F401

_REGISTRY = {"baseline": build_model}


def make_model(cfg: dict[str, Any]):
    """Build the model named by cfg['model'] ('baseline' default)."""
    name = cfg.get("model", "baseline")
    return _REGISTRY[name](cfg)
