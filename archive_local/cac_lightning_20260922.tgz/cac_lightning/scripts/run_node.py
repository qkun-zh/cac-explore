#!/usr/bin/env python3
"""Run a Lightning training from a TOML config.

Usage:
  python scripts/run_node.py --config configs/baseline.toml --run-dir runs/x [--epochs N] [--smoke] [--name label]

Prints a single `RESULT {json}` line and writes run_dir/result.json.
Note: this CLI is trivial by design — all logic lives behind cac.engine.run.
"""
from __future__ import annotations

import argparse
import json
import os
import sys

# make `cac` importable without installing the package
_SRC = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src")
if _SRC not in sys.path:
    sys.path.insert(0, _SRC)


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--config", required=True, help="path to TOML config")
    p.add_argument("--run-dir", default=None, help="output dir (default: runs/<name>)")
    p.add_argument("--name", default=None)
    p.add_argument("--epochs", type=int, default=None)
    p.add_argument("--smoke", action="store_true")
    args = p.parse_args()

    from cac.config import load_config
    from cac.engine import run

    cfg = load_config(args.config)
    name = args.name or os.path.basename(args.config).rsplit(".", 1)[0]
    run_dir = args.run_dir or os.path.join("runs", name)
    model_file = None
    sibling = os.path.join(os.path.dirname(os.path.abspath(args.config)), "model.py")
    if os.path.isfile(sibling):
        model_file = sibling
    result = run(cfg, run_dir, name=name, smoke=args.smoke, max_epochs=args.epochs,
                 model_file=model_file)
    print("RESULT " + json.dumps(result, ensure_ascii=False), flush=True)


if __name__ == "__main__":
    main()
