#!/usr/bin/env python3
"""Discovery orchestration (HypoExplore machinery).

Replaces the old select_next.py / check_hypothesis.py / rebuild_index.py /
calibration_report.py with one entrypoint:

  python scripts/discovery.py parent                # pick next parent node
  python scripts/discovery.py hypo --parent N0001_x # pick Q_t hypothesis set
  python scripts/discovery.py validate --text "IF ..."   # format gate
  python scripts/discovery.py rebuild               # materialize index from ledger
  python scripts/discovery.py calibration [--json]  # calibration monitor
"""
from __future__ import annotations

import argparse
import json
import os
import sys

_SRC = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src")
if _SRC not in sys.path:
    sys.path.insert(0, _SRC)

from cac.expt import Calibration, Memory, TrajectoryTree  # noqa: E402


def main() -> None:
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="mode", required=True)

    sub.add_parser("parent")
    hp = sub.add_parser("hypo")
    hp.add_argument("--parent", required=True)
    hp.add_argument("--seed", type=int, default=None)

    hv = sub.add_parser("validate")
    hv.add_argument("--text", default=None)
    hv.add_argument("--file", default=None)

    sub.add_parser("rebuild")

    hc = sub.add_parser("calibration")
    hc.add_argument("--json", action="store_true")

    args = ap.parse_args()

    mem = Memory()
    tree = TrajectoryTree()

    if args.mode == "parent":
        idx = mem.build_index()["hypotheses"]
        tree.select_parent(idx)

    elif args.mode == "hypo":
        idx = mem.build_index()["hypotheses"]
        tree.select_hypo(args.parent, idx, seed=args.seed)

    elif args.mode == "validate":
        text = args.text or (open(args.file).read() if args.file else sys.stdin.read())
        from cac.expt import validate as v
        errs, warns = v(text)
        for e in errs:
            print(f"ERROR {e}", file=sys.stderr)
        for w in warns:
            print(f"warn  {w}")
        sys.exit(1 if errs else 0)

    elif args.mode == "rebuild":
        idx = mem.build_index()
        print(f"rebuilt index: {len(idx['hypotheses'])} hypotheses")

    elif args.mode == "calibration":
        print(Calibration().report(as_json=args.json) if args.json
              else Calibration().report())


if __name__ == "__main__":
    main()
