# AGENTS.md — Hypothesis-Driven Discovery on PyTorch Lightning

Implementation of HypoExplore (arXiv:2604.12999) for FSC147 crowd counting on
PyTorch Lightning. Standalone repo: the pipeline and orchestration are fully
self-contained here. Deviations from the paper are explicit (§9).

**Mission**: ≤32M total params, same-parameter-class SOTA MAE on FSC147 test.

**Regime (fixed, proven)**: FROZEN intermediate backbone readout hs(2,3) — the
load-bearing count-semantic readout. Head-side pluggable innovation is the only live
innovation channel (2×2 map: any unfreeze or final-layer readout is net-harmful).
Optimizer/loss/schedule fixed (AdamW, cosine, MSE(+count)); see configs/baseline.toml.

**Training engine**: Lightning `Trainer` + `CountingLit(LightningModule)` +
`FSC147DataModule(LightningDataModule)`. The model forward contract
`build_model(cfg) -> forward(imgs,bboxes[,bboxes3]) -> {"density", optional n_aux}`
is preserved. Only `out["density"]` feeds the loss/gradient.

## 1. Repo Map

| Path | Role |
|---|---|
| `configs/baseline.toml` | Single source of truth (model + train settings, seeded) |
| `src/cac/config.py` | `load_config(path) -> flat dict` |
| `src/cac/models/counter.py` | `build_model(cfg)` frozen backbone + pluggable head |
| `src/cac/models/pl_module.py` | `CountingLit` — loss/optimizer/scheduler/val metrics |
| `src/cac/data/pl_datamodule.py` | `FSC147DataModule` — datasets, seeded loaders, smoke |
| `src/cac/engine/runner.py` | `run(cfg, run_dir, ...)` — Trainer.fit + best.pth + result.json |
| `src/cac/calls/best_checkpoint.py` | writes `best.pth` |
| `src/cac/expt/` | Orchestration: `Memory`, `TrajectoryTree`, `Calibration` |
| `scripts/run_node.py` | Lightning training entrypoint |
| `scripts/discovery.py` | Selection + gates + index/calibration entrypoint |
| `scripts/install_key.py` | Server re-onboarding after address/password rotation (reads `local/`) |
| `local/address_and_password.md` | git-ignored server creds (address/password), see §7 rotation |
| `tree/tree.json` | Trajectory tree (node registry) |
| `memory/hypotheses.jsonl` | Append-only hypothesis ledger |
| `memory/index.json` | Materialized index (rebuildable from ledger) |
| `nodes/<ID>/` | One dir per experiment: idea.md, model.py, config.toml, feedback/, synthesis.md |
| `tests/` | Pure-Python unit tests for orchestration |
| `docs/` | research_direction.md (mission), head_census.md (head ablation), backbone_intermediate.md |

## 2. Startup Sequence (mandatory, in order)

1. `cd ~/cac_lightning && git pull --ff-only`
2. Read this file, then `docs/research_direction.md` (owns the mission target).
3. Preflight: `ssh -o ConnectTimeout=8 -o BatchMode=yes cac-server 'echo SERVER_OK'`
   - Server address/password rotate often and are NEVER hard-coded in this repo.
     They live in the git-ignored `local/address_and_password.md` (see §7).
4. Check the running training: `ssh cac-server 'tail /data/cac_lightning/runs/<name>/train.log'`

## 3. Roles — the Lead Is an Orchestrator

The Lead never personally writes idea.md, model.py, feedback/*.md, or synthesis.md.
Every role is dispatched to an independent subagent. One card = one subagent = one
fresh context. Independent work launches in parallel.

| Role | Who | Produces |
|---|---|---|
| Researcher | Subagent | SOTA analysis folded into research_direction.md |
| Idea Agent | Subagent | `idea.md` + novelty statement + task card |
| Coding Agent | Subagent | `nodes/<ID>/model.py` + `config.toml` + green `--smoke` |
| Executor | Lead only | Server training via run_node.py |
| Feedback ×3+1 | Subagents in parallel | feedback/{quant,qual,causal}.md (+ diagnostic on failure) |
| Synthesis | Subagent | synthesis.md + hypothesis bookings + calibration table |

**Lead-exclusive**: tree.json status flips · git ops · journal · memory bookings.

## 4. Research Cycle (one pass per iteration)

1. **Bootstrap**: if tree empty → generate K=4 root nodes from research_direction.md (parent=null).
2. **Pick parent**: `python3 scripts/discovery.py parent`
3. **Pick hypotheses**: `python3 scripts/discovery.py hypo --parent <ID>`
4. Idea agent (parallel multi-angle lenses) → Coding agent writes model.py + config.toml
   → `python3 scripts/run_node.py --config <node>/config.toml --smoke` (green required).
5. Executor (Lead): real training on server, freestanding (see §7).
6. Feedback ×4 + Synthesis (dedup, contradiction resolution, calibration gate).
7. Update tree.json / index.json / docs; commit & push.

## 5. Gates (never skip)

1. **Format** — `python3 scripts/discovery.py validate --file <idea.md>` (7-dim).
2. **Novelty** — idea agent structural judge vs memory bank.
3. **Calibration** — `python3 scripts/discovery.py calibration` table in every synthesis.md.

## 6. Hypothesis Format & Confidence

    IF [choice] IN [scope], THEN [effect], BECAUSE [mechanism]. DISPROVED IF [criterion].

η=0.20 · support c←c+η·w·(1−c) · contradict c←c−η·w·c · confirmed >0.75 · refuted <0.25.
Ledger is append-only; corrections are new events. The ledger confidences are advisory —
the node statuses in `tree/tree.json` are the operational record that governs retries
(a single event cannot cross 0.25).

## 7. Server Cheat-Sheet
| Item | Value |
|---|---|
| Connection | `ssh cac-server` |
| Repo (server) | `/data/cac_lightning` (pull-only; local pushes) |
| Python | `/data/miniconda/envs/cac/bin/python` |
| HF cache | `HF_HOME=/data/asset/hf`, `HF_ENDPOINT=https://hf-mirror.com` |
| Runs | `/data/cac_lightning/runs/<name>/` (best.pth, result.json, train.log) |
| Dataset | `/data/dataset/FSC147` |
| GPU | single RTX 3060 12GB |

Launch real training (freestanding, survives ssh close):
```bash
ssh cac-server 'cd /data/cac_lightning && export HF_HOME=/data/asset/hf \
  && setsid python scripts/run_node.py --config <node>/config.toml --run-dir runs/<name> > runs/<name>/train.log 2>&1 < /dev/null &'
```

**Server address rotation** (the cloud GPU server's public IP/port/password change
frequently; never harder-edited into this repo or `~/.ssh/config`):
1. Update the git-ignored `local/address_and_password.md` (gitignored, `0600`):
   ```
   ssh -p <port> <user>@<host>
   <password>
   ```
2. Re-onboard + re-write the `cac-server` SSH alias (installs the pubkey on the box,
   persists it under `/data/.ssh`, and rewrites `~/.ssh/config`):
   ```bash
   python3 scripts/install_key.py
   ```
3. Verify: `ssh cac-server 'echo SERVER_OK'`

## 8. File Contracts & Node Lifecycle

**Sync topology (single-writer)**: only local pushes. Server clone is read-only;
run artifacts live under `/data/cac_lightning/runs/<ID>/` and are read back via ssh
(no scp — checkpoints stay on the server; ledger/index/tree live in git).

**Node directory `nodes/<ID>/`** — ID `N####_<short-name>`; next free = max+1; a
root node has parent=null.

| File | Author | Content |
|---|---|---|
| `idea.md` | Idea Agent | `## Title`, `## Motivation & Intuition`, `## Architecture Spec`, `## Proposed Hypotheses` (with falsification), `## Delta vs Parent`, `## Novelty Statement` |
| `model.py` | Coding Agent | `build_model(cfg) -> nn.Module`; forward `(imgs, bboxes[, bboxes3]) -> {"density", optional n_aux}`; density may be low-res (engine upsamples, sum-conserving) |
| `config.toml` | Coding Agent | Single TOML; only required key `input_size`; see configs/baseline.toml for the canonical set |
| `result.json` | Executor | `{node, status, metrics:{mae,rmse,best_mae}, timing, diagnostics, run_dir, ts}` |
| `feedback/*.md` ×4 | Feedback | `## reasoning` / `## actionable_feedback` / `## hypothesis_updates` |
| `synthesis.md` | Synthesis | Dedup, quality-gate verdict, bookings, calibration table |

**Global state files**: `tree/tree.json` `{_meta, nodes:{<ID>:{parent,
children[], status, best_metric, train_seconds, tested_hypotheses[]}}}` — status
`proposed|coded|running|done|failed|timeout|synthesized`. `memory/hypotheses.jsonl`
append-only ledger. `memory/index.json` materialized snapshot (rebuild via
`discovery.py rebuild`).

**Dual selection (`scripts/discovery.py`)**:
- `parent`: `score = λ_parent·quality + (1−λ_parent)·avail`, with
  `quality = λ_acc·Acc_norm + (1−λ_acc)·(1 − min(τ,τ_max)/τ_max)`,
  λ_acc=0.85, λ_parent=0.60, τ_max=30min.
- `hypo --parent <ID>`: exploit = Thompson sampling Beta(α,β), top-2; explore =
  epistemic `1−|2c−1|`, top-2; deduped union ≤4; only uncertain & untested-on-chain.

**Smoke mode** (synthetic data, 2 epochs, CPU-capable; verifies model/config
contract before a real run):
```bash
CAC_ACCELERATOR=cpu python3 scripts/run_node.py --config <node>/config.toml --smoke
```

## 9. Recorded Deviations from arXiv:2604.12999

| Paper component | Local practice |
|---|---|
| Hand-written training loop | Replaced by PyTorch Lightning Trainer/LightningModule/DataModule |
| Per-node engine | Single Lightning engine; config TOML drives every node |
| Hyperparameter refinement F_max=5 | None — config authored once |
| Novelty embedding filter | Idea agent structural judge (no external embedding API) |
