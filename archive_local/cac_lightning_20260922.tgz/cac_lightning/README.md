# cac_lightning — FSC147 crowd counting on PyTorch Lightning

Counting pipeline on Lightning: the `Trainer` + `LightningModule` +
`LightningDataModule` drive training, and discovery orchestration (HypoExplore
trajectory tree, memory bank, gates) lives in the self-contained `src/cac/expt/`
package. Repo is standalone — no external engine dependency.

## Layout (deep modules, clean seams)

| Path | Role |
|---|---|
| `configs/baseline.toml` | Single source of truth (all model + train settings, seeded) |
| `src/cac/config.py` | `load_config(path) -> flat dict` (nested tables flattened to dotted keys) |
| `src/cac/models/counter.py` | `build_model(cfg)` -> nn.Module, frozen backbone + pluggable head |
| `src/cac/models/pl_module.py` | `CountingLit(LightningModule)` — loss, optimizer, scheduler, val metrics |
| `src/cac/data/pl_datamodule.py` | `FSC147DataModule(LightningDataModule)` — datasets, seeded loaders, smoke |
| `src/cac/engine/runner.py` | `run(cfg, run_dir, ...)` — wires Trainer + writes result.json/best.pth |
| `src/cac/calls/best_checkpoint.py` | writes `best.pth` |
| `src/cac/expt/hypothesis.py` | `Memory` — append-only ledger, format gate, confidence updates, index |
| `src/cac/expt/tree.py` | `TrajectoryTree` — node registry + dual selection |
| `src/cac/expt/gates.py` | `Calibration` — hypothesis prediction calibration monitor |
| `scripts/run_node.py` | Lightning training CLI |
| `scripts/discovery.py` | Selection + format gate + index rebuild + calibration CLI |
| `scripts/install_key.py` | Re-onboard the GPU server after its address/password rotates (reads git-ignored `local/`) |
| `tree/tree.json` | Trajectory tree (empty initially) |
| `memory/` | Append-only hypothesis ledger + materialized index |
| `nodes/<ID>/` | One dir per experiment (idea.md, model.py, config.toml, feedback/, synthesis.md) |

## Training

```bash
# CPU smoke (no dataset, synthetic)
CAC_ACCELERATOR=cpu python scripts/run_node.py --config configs/baseline.toml --smoke

# real training on GPU
python scripts/run_node.py --config configs/baseline.toml --run-dir runs/baseline --epochs 32
```

## Discovery

```bash
python scripts/discovery.py parent                    # pick next parent node
python scripts/discovery.py hypo --parent N0001_x     # pick Q_t hypothesis set
python scripts/discovery.py validate --file nodes/N/idea.md   # format gate
python scripts/discovery.py rebuild                   # rebuild index.json from ledger
python scripts/discovery.py calibration               # calibration monitor
```

See `AGENTS.md` (protocol/roles/gates/contracts).

## Reproducibility
A fixed `seed` in the TOML -> `_seed()` (torch/numpy/random + cudnn.deterministic)
+ seeded DataLoader generator/worker_init_fn + deterministic Trainer. A given config
+ seed reruns bit-identically.

## Training recipe (fixed)
- Loss: MSE(density) + `loss_count_weight` * L1(sum(density), count); only
  `out["density"]` feeds gradients.
- Optimizer/schedule: AdamW(betas) + CosineAnnealingLR, one step per epoch.
- AMP: fp16-mixed + GradScaler on GPU. Grad clip: max-norm.
- Model forward contract `build_model(cfg)` is preserved across all nodes.

