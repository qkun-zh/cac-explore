# Research Direction (human-specified)

## Direction Statement

On FSC147 class-agnostic counting, discover lightweight, accurate, transferable CAC
architectures via hypothesis-driven multi-agent evolutionary search, trained on
PyTorch Lightning.

**Target**: ≤32M parameters, MAE ≤ 10 on FSC147 **test**.

## Task Definition

- Input: RGB image + exemplar box(es) indicating the target category
- Output: density map whose integral is the predicted count
- Metrics: MAE (primary), RMSE (secondary); official FSC147 splits

## Dataset Layout (server `/data/dataset/FSC147`, VarV2)

```
FSC147/
├── images_384_VarV2/<id>.jpg
├── gt_density_map_adaptive_384_VarV2/<id>.npy
├── annotation_FSC147_384.json     # {"<id>.jpg": {"W","H","box_examples_coordinates"...}}
└── Train_Test_Val_FSC_147.json    # {"train":[...], "val":[...], "test":[...]} — 6146 imgs / 147 cats
```

Loader `src/cac/data/fsc147.py`; density resampling is sum-preserving (counts unchanged).

## Constraints

- **Backbone**: pretrained from HF (DINOv3-ConvNeXt-Tiny). **FROZEN intermediate readout
  hs(2,3)** — this is the load-bearing count-semantic readout and the canonical baseline.
  The 2×2 map (readout-layer × freeze-state) is complete and all four experimental cells
  are negative vs the frozen-intermediate champion: unfreezing is net-harmful (6–9 pts),
  final-layer readout loses ~7 pts. Backbone layer/freeze axis is CLOSED.
- **Parameter budget**: ≤32M total (backbone counts). Engine asserts `max_params_M`.
- Single RTX 3060 12GB, AMP (fp16-mixed via Lightning).
- Architecture must expose `build_model(cfg)` — see AGENTS §8 (file contracts).

## Baseline Reference

`configs/baseline.toml` is the canonical champion recipe: GCA + XScale multi-scale
exemplar, frozen intermediate readout, cross-attn condenser. Known-proven components
(GCA +1.6, XScale +0.95, intermediate frozen +7) must not be dropped while exploring.

## Server notes
`run_node.py` exports `HF_HOME=/data/asset/hf` + `HF_ENDPOINT=https://hf-mirror.com`.
First run downloads backbone weights once; cache persists in /data.
