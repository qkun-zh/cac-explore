# Head Ablation Census — the live innovation channel & discovery status

Backbone 轴已 CLOSED (`hs(2,3)` frozen 是唯一 load-bearing readout)。head 是全项目唯一的
活跃创新通道。本档是本轮发现搜索的权威快照：head 侧 10ep/32ep 消融、假设账本状态、为什么
baseline 难被打败，以及下一轮结构级方向。All numbers `seed=212421`, `384/bs16/amp`, RTX
3060, unless noted.

> 方法论:所有对照同 `seed=212421`、`384/bs16/amp/deterministic=False`。
> **关键教训:3 轮完全不分化(全部 39~48),必须 ≥10 轮才有可靠的排序**;
> 且 10 轮结论与 32 轮稳态可能相反(见 GCA),重大方向必须拉到 32 轮复核。

## 1. 10ep 对照表 (same seed 212421, best_mae)

| 节点 | 改动 | 10ep best | vs baseline 26.02 | 32ep best | vs 22.19 |
|---|---|---|---|---|---|
| baseline | (冠军配置) | 26.02 | — | **22.19** | — |
| N0007 | decoder +1 层 (deeper) | 26.49 | +0.48 | — | — |
| N0008 | decoder hidden 256→192 (light) | 26.61 | +0.59 | — | — |
| N0005 | **use_gca=false** | **25.16** | **-0.86** | — | 23.00 (N0009) +0.81 |
| N0006 | **use_xscale=false** | **28.69** | **+2.67** | — | — |
| N0010 | xscale_size 3→5 | 27.38 | +1.36 | — | — |
| N0011 | XScale coarse→cross-attn fusion | 30.34 (REAL) | +4.3 | — | — |
| N0012 | decoder count-consistency blend norm | DIVERGES | — | — | — |

## 1b. Exemplar readout 对照表 (N0014-N0016, 32ep)

第二轮发散方向：**exemplar 读取深度**。在 N0015 首次击败 baseline。固定 hs(3)+hs(4) 双分支
读取是当前冠军。

| 节点 | 改动 | 32ep best | vs baseline 22.19 | vs 21.68 |
|---|---|---|---|---|
| baseline | exemplar 纯 hs(3) 中间层 | 22.19 | — | — |
| N0014 | exemplar 纯 hs(4) final 层 | 22.67 | +0.48 | — |
| **N0015** | **hs(3)细节+hs(4)语义 固定加性融合** | **21.68** | **-0.51** | — |
| N0016 | hs(3)+hs(4) 可学习 per-exemplar 软路由 | 22.38 | +0.19 | +0.70 |

**结论 (exemplar 轴)**:
1. **双分支固定融合是 exemplar 读取的局部最优** (H_HEAD_EXFUSE, conf 0.5):h3 细节+
   h4 语义固定相加 beats 任何单源读取 (baseline 22.19 和 N0014 final-only 22.67)。唯一
   击败 baseline 的 head 改动。
2. **final-only 单源差于中间层** (H_HEAD_EXDEEP refuted):12×12 低分辨率 exemplar 的细节
   损失 > final 语义增益。即使 exemplar 读取也偏好中间 hs(3)。
3. **per-exemplar 软路由是负收益** (H_HEAD_EXROUTE refuted, +0.70 vs N0015):可学习
   [w_mid,w_final] router 比固定加法更差。best 在 e17(22.38) 后回落到 ~23.0,router 未学会
   稳定深度分流。**教训**:DCA-MoE SALF 的价值在**高分辨率密度图逐位置路由**,而非降采样
   exemplar ROI 上的路由——后者固定融合已近最优。

## 2. 结论 (ranked by confidence)

1. **XScale 是 load-bearing** (H_HEAD_XS, conf 0.54):移除 +2.67 @10ep。这是 head 里唯一确认
   的正向关键件——它的 coarse 全局汇总(per-exemplar GAP+proj)提供尺度不变性。
2. **xscale_size=3 是局部最优** (H_HEAD_XS5, conf 0.46):放大到 5 反而 +1.36,粗池过大引入噪声。
   → 不要在此轴上再试更大值。
3. **GCA 是 marginal 且 early/steady 相反** (H_HEAD_GCA):
   - 10ep 移除 GCA 反而 **更好** (-0.86)
   - 32ep 移除 GCA **更差** (+0.81, N0009 best 23.00)
   - 即:doc 里 "GCA +1.6" 高估了;真实稳态贡献约 +0.8,但在早期(10ep)是负的。
   - **决策**:保留 GCA(稳态仍有微弱收益),但不要指望它是差异化的卖点。
4. **decoder 已到局部最优** (H_HEAD_DEEP/LIGHT):加深 +0.48、变轻 +0.59 都更差。
   `2×卷积(hidden256)` 是该容量的甜点,别再动。
5. **XScale 的 coarse 融合方式已近最优** (H_HEAD_CA, conf 0.47):把 coarse 从「加性 add」
   改成 cross-attention 融合,10ep 无增益 (+0.13)。说明现有 GAP+xproj+add 已充分。
   → coarse 分支内部语义融合不是差异化方向。

## 3. 结论: baseline 处于扎实的局部最优

本轮已试探 head 侧每一个可及轴:decoder 深度/容量、GCA、XScale 存在性、xs 数值、coarse 融合
方式。**全部非正**:唯一 load-bearing 的 XScale 已探索到位,其余微调都是在局部最优附近的
负梯度。这本身是有价值的信息——它确认 baseline (22.19) 不是「随便配的」,而是每一格都被推过
的较优配置。

真正剩余的差异化空间不在这些单点超参,而是**跨组件的联合创新**(如把全局计数 bias 直接灌进
density decoder 的空间分支,而非 GCA 那样的独立 aux),或引入 training 侧的新机制
(EMA/tail-reweight,见 research_direction 未实作的粗体项)。这些需要结构级设计,而非本轮这类
逐格扫描。

## 4. 复现

> **⚠️ 完整性修正 (2026-08-30)**:早期 N0004/N0011/N0012 的 `model.py` 是死代码——runner 始终用
> `make_model`(静态 registry)构建模型,**忽略节点本地 `model.py`**。因此那 3 个节点跑的是
> baseline(依 config),并非其标注的架构。已修复 runner(`_build`/`_load_node_model` + run_node
> 检测 config 同目录 `model.py`),并用**真实验证**重跑:
> - N0004 解冻 +2.9 @10ep (28.92) —— 确认解冻有害,支持 CLOSED 2×2
> - N0011 cross-attn 融合 +4.3 @10ep (30.34) —— 强有害,加性融合近最优
> - N0012 count-consistency 归一化 **发散** (mae 6324) —— 架构数值损坏
> 仅 config-flag 驱动的节点 (N0001-3 hs2/hs3/final, N0005/6 GCA/XScale, N0009, N0010) 有效,
> 但存在 ~±0.6 best_mae 的 run-to-run 方差 (同 seed 下 deterministic=False 的非确定性)。
> **教训**:架构级 node 必须改 `model.py` 且确认被加载(改 config-flag 不可达的路径),结果需以
> 修复后为准。

```bash
cd /data/cac_lightning && export HF_HOME=/data/asset/hf
# 10ep 快照
for node in baseline N0005_no_gca N0006_no_xscale N0010_xscale5; do
  python scripts/run_node.py --config nodes/$node/config.toml --run-dir /tmp/${node}_10ep --name $node --epochs 10
done
# 关键方向复核到 32ep (N0009 = no_gca -> best 23.00)
python scripts/run_node.py --config nodes/N0009_no_gca/config.toml --run-dir runs/N0009 --name N0009 --epochs 32
```

## 5. Hypotheses ledger (memory/hypotheses.jsonl)

Confirmed-positive: **H_HEAD_XS (XScale)** conf→0.54 and **H_HEAD_EXFUSE (exemplar
h3+h4 fusion)** conf→0.5 — the two support-ed head hypotheses (XScale is load-bearing
infrastructure; EXFUSE is the current SOTA driver). All others drifted down
(refuted/uncertain): H_HEAD_GCA, H_HEAD_DEEP/LIGHT, H_HEAD_XS5, H_HEAD_CA, H_HEAD_CCN,
H_HEAD_EXDEEP, H_HEAD_EXROUTE, H_TRAIN_EMA. Backbone axes H_BB1-5 remain 'uncertain'
(3ep only, not discriminative).

## 6. Why baseline is hard to beat

- Cosine + weight_decay 0.08 already regularize → EMA adds nothing.
- Frozen backbone readout + XScale coarse fusion + 2×conv decoder is a mature design —
  every single-axis perturbation is a negative gradient.
- The 10ep snapshot is NOT discriminative for fine differences; 32ep is the arbiter
  (GCA/EMA both flipped sign between 10ep and 32ep).
- **Exemplar readout was the exception**: fusing h3 detail + h4 semantics beats baseline
  (N0015, -0.51). This is the one axis where a structural change was additive, not
  subtractive — the starting `hs(2,3)` density readout never touched exemplar depth.

## 7. Next iteration (structural, not tweaks)

Standing champion: **N0015 (21.68)** — exemplar = h3+h4 fixed additive fusion, shared
transformer, 31.4M total. Within-budget head tweaks are largely exhausted, but two
learned lessons point onward:

1. **SALF value is per-position routing on the density map, NOT on downsampled exemplar
   ROIs** (N0016 refuted ROI-routing but validated the principle). Put the DCA-MoE
   spatially-adaptive multi-receptive-field experts into the **DensityDecoder** (per
   spatial position route local/mid/large receptive fields), orthogonal to exemplar.
2. **Multi-resolution input** (config flag `multires=false` is a stub) — 2-res input is
   the strongest known counting gain (CounTR/DCG+), but needs data+model+amp-memory work
   on 12GB.
3. **Exemplar augmentation** / data strategy is untouched.

Recommendation before heavy re-design: a **replication run of N0015** (32ep) to confirm
the -0.51 beat is stable against run-to-run variance (~±0.6), since it is currently a
single run backing the only SOTA hypothesis. Do NOT re-probe the refuted axes (GCA
direction, XScale removal, XS5, CA, EMA, EXDEEP, EXROUTE, EXDEEP). Next pass: dispatch
the Researcher to re-analyze density-decoder spatial routing (DCA-MoE) as a fresh root.
