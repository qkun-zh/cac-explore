# Backbone 中间层的作用 — 机制、证据与可复现对照设计

## 1. 背景与问题

FSC147 类无感知计数（CAC）的核心矛盾是：需要在**保留空间分辨率**的同时获得**类别无关的计数量子语义**。Backbone 的不同深度恰好在这两个维度上做 trade-off：

* **浅层 (hs1, 96ch, 96×96)**：分辨率高、语义低（边缘/纹理），类别无关但缺乏“这是一个物体”的抽象。
* **中层 (hs2 192ch 48×48 / hs3 384ch 24×24)**：分辨率中等、语义中等，DINOv3 预训练在此处恰好编码了“可数实体”的通用表征（count-semantic），既能定位又能区分。
* **深层 (hs4 768ch 12×12)**：分辨率极低、语义高度分类特化（ImageNet/DINO 类别），空间信息被压缩，计数所需的密度细节丢失。

本项目在 `src/cac/models/counter.py:29` 固定 `hs_map=(2,3)` 作为 **frozen intermediate readout**，并在 `docs/research_direction.md:31` 标注该轴已 CLOSED：2×2（readout × freeze）四格对照已全部为负——解冻 +6~9 pts，改 final +7 pts。本档**不是要推翻 CLOSED，而是把“为什么”讲透，并给出可复现的 3 轮快速对照，让后人一键复验**。

## 2. 已有 2×2 证据（稳态，不再全量重跑）

| readout | frozen (eval) | unfrozen (train) | 差值 |
|---|---|---|---|
| hs(2,3) intermediate | **22.19 (当前 seed 212421, 32轮)** | +6~9 pts (历史) | 解冻破坏 DINO 通用特征，过拟合到 147 训练类 |
| hs(4) final | +7 pts (历史) | +7~+9 pts (历史) | 最差格 |

> 旧引擎与新 Lightning 在 `384/bs16/num_workers4/amp` 同配置下已对齐：旧 `55s/轮` vs 新（修 deterministic 后）`~55s/轮`，见 `src/cac/engine/runner.py:95` 修复记录。数值可复现，机制可解释。

## 3. 机制假说（可证伪）

**H-BB1 — hs2 单层不足**  
`IF hs2-only IN FSC147, THEN MAE +3~5 vs hs(2,3), BECAUSE hs2 语义不足以做 exemplar 匹配（仅 192ch 中层纹理），DISPROVED IF 3轮对照中 gap <1.0`

**H-BB2 — hs3 单层不足**  
`IF hs3-only, THEN MAE +2~4, BECAUSE hs3 分辨率 24×24 对小目标密度欠采样，细粒度定位丢失，DISPROVED IF gap <1.0`

**H-BB3 — final 层最差**  
`IF hs4-only (768ch 12×12), THEN MAE +7, BECAUSE 分类特化 + 12×12 过粗，密度上采样需 8× 插值，累计误差，DISPROVED IF gap <3.0`

**H-BB4 — 解冻有害**  
`IF unfrozen hs(2,3), THEN MAE +6~9, BECAUSE DINOv3 计数量子语义被 6k 图微调覆盖，泛化到 unseen 类下降，DISPROVED IF 3轮内 gap <2.0`

**H-BB5 — 浅层无增益**  
`IF hs(1,2,3), THEN MAE ±1, BECAUSE hs1 (96ch) 仅边缘，无计数增益且引入噪声，DISPROVED IF 提升 >1.5`

置信度更新沿用 `memory` 账本 `η=0.20`，阈值 `confirmed>0.75 / refuted<0.25`。

## 4. 一键可复现的 3 轮对照（设计而非全量）

每个对照仅 3 轮（~3分钟/个，空闲 GPU 上 `deterministic=False` 时 `~65s/轮`），不求收敛到 22，仅求**排序**复现 2×2 结论。配置通过 `Backbone.hs_map` 与 `backbone_dims` 驱动，无需改 `CountingHead` 以外：

| 节点 | hs_map | dims | freeze | 预期 3轮 MAE 排序 |
|---|---|---|---|---|
| baseline hs23 frozen | (2,3) | [192,384] | frozen | 1 (best, ~27 @3轮) |
| hs2_only | (2,) | [192] | frozen | 2-3 |
| hs3_only | (3,) | [384] | frozen | 2-3 |
| final_only | (4,) | [768] | frozen | 5 (worst) |
| hs23_unfrozen | (2,3) | [192,384] | unfrozen | 4 |

> 实现要点：`Backbone.forward_feature_map` 返回 `hs[i] for i in hs_map`；`FineFuser` 需适配单层输入（退化为单分支）；`ExemplarEncoder` 的 `in_dim` 取 `dims[-1]`。已在 `nodes/` 下提供模板 `model.py`（见 §5）。

## 5. 为什么 intermediate + frozen 是 load-bearing

1. **分辨率-语义甜点**：`48×48 + 24×24` 经 `FineFuser` 融合到 `96×96 (S/4)`，恰好是密度图 `S/4` 的原生分辨率，无需 8× 上采样（final 需 8×，误差累积）。这是**架构几何**决定的。
2. **预训练语义**：DINOv3-ConvNeXt-Tiny 的中层在 LVD1689M 上学到的是“物体性”而非“类别性”，对 CAC 的跨类泛化至关重要。Final 层在预训练末期被分类头“拉偏”，计数信号被稀释。
3. **冻结的正则作用**：FSC147 仅 3.6k 训练图、147 类，微调 27.8M backbone 极易过拟合训练类，破坏通用计数能力。冻结等价于**用 6k 图去学 3.5M head 的计数器**，而非用 6k 图去改 31M 的视觉表征。

## 6. 复现步骤

```bash
# 单个对照（3轮，~3分钟）
python scripts/run_node.py --config nodes/N000X_hs2_only/config.toml --run-dir /tmp/hs2 --epochs 3
python scripts/run_node.py --config nodes/N000X_final_only/config.toml --run-dir /tmp/final --epochs 3
# 全量 baseline（32轮，~27分钟，已跑 seed 212421 -> best 22.19）
python scripts/run_node.py --config configs/baseline.toml --run-dir runs/baseline --name baseline
```

所有节点 `model.py` 暴露 `build_model(cfg)`，`forward(imgs,bboxes) -> {"density"}` 契约不变；`best.pth` 仍为旧兼容格式。

## 7. 结论与后续

* **不要再在 backbone 层/冻结轴上投入全量搜索**：2×2 已闭合，边际收益为负，算力应投向 head 侧（GCA/XScale/condenser/decoder）。
* 本档提供的 3 轮对照是**教学性复现**，用于新成员理解“为什么是中间层”，而非竞赛性调参。
* 若未来换 backbone（如 ViT），需重做同款 `hs_map` 扫描，因为 ViT 的层-分辨率映射不同。

---
*Source: `src/cac/models/counter.py:14-33`, `configs/baseline.toml:12-15`, `src/cac/engine/runner.py:95` fix, server hidden-states probe `hs[1..4]` shapes (96/192/384/768).*
