"""End-to-end tests for the expt orchestration (pure Python, no torch).
Run: python3 tests/test_expt.py
"""
import json
import os
import shutil
import sys
import tempfile

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from cac.expt import Calibration, Memory, TrajectoryTree, validate


GOOD = ("IF GCA aux IN baseline, THEN improves val MAE, BECAUSE global count head "
        "anchors density integral to a single scalar and slashes count-variance of sparse "
        "scenes. DISPROVED IF val MAE worsens by >=1.5 points.")


def make_repo(tmp):
    os.makedirs(os.path.join(tmp, "memory"))
    os.makedirs(os.path.join(tmp, "tree"))
    open(os.path.join(tmp, "memory", "hypotheses.jsonl"), "w").close()
    json.dump({"_meta": {}, "hypotheses": {}}, open(os.path.join(tmp, "memory", "index.json"), "w"))
    json.dump({"_meta": {"lambda_acc": 0.85, "lambda_parent": 0.60, "tau_max_min": 30, "eta": 0.20,
                         "k_exploit": 2},
               "nodes": {}}, open(os.path.join(tmp, "tree", "tree.json"), "w"))
    return tmp


def run_all():
    tmp = make_repo(tempfile.mkdtemp())

    # format gate
    e, w = validate(GOOD)
    assert not e, e
    e, _ = validate("GCA is good maybe")
    assert e, "bad hyp should fail"

    # memory: create + evidence + index
    mem = Memory(tmp)
    mem.create("H0001", GOOD, source="N0001_x")
    mem.create("H0002", GOOD.replace("GCA", "XScale").replace("global count head", "coarse exemplar summary"),
               source="N0001_x")
    mem.evidence("H0001", "supports", 1.0, "N0001_x")
    mem.evidence("H0001", "supports", 0.8, "N0002_x")
    idx = mem.build_index()["hypotheses"]
    assert idx["H0001"]["n_tested"] == 2
    assert abs(idx["H0001"]["confidence"] - ((0.5 + 0.2 * 1.0 * 0.5) + 0.2 * 0.8 * 0.4)) < 1e-6
    assert len(mem.events()) == 4

    # calibration
    cal = Calibration(tmp)
    rep = cal.report()
    assert "Calibration" in rep

    # tree: register + selection
    tree = TrajectoryTree(tmp)
    tree.register("N0001_x", None)
    tree.register("N0002_x", "N0001_x")
    tree.set_status("N0001_x", "done")
    tree.update_metrics("N0001_x", 19.6, 1200, tested=["H0001"])
    tree.set_status("N0002_x", "synthesized")
    tree.update_metrics("N0002_x", 20.5, 1300, tested=["H0002"])
    idx = mem.build_index()["hypotheses"]
    parent = tree.select_parent(idx, verbose=False)
    # N0002 has lower quality (worse MAE) but H0002 untested -> availability favors it
    assert parent in ("N0001_x", "N0002_x")
    qt = tree.select_hypo(parent, idx, seed=1, verbose=False)
    assert isinstance(qt, list)

    # next_id
    nid = tree.next_id()
    assert nid.startswith("N0003_"), nid

    shutil.rmtree(tmp)
    print("ALL EXPT TESTS PASS")


if __name__ == "__main__":
    run_all()
